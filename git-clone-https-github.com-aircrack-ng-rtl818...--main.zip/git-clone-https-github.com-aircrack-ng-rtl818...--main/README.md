# git-clone-https-github.com-aircrack-ng-rtl818...-
installing aircrack
